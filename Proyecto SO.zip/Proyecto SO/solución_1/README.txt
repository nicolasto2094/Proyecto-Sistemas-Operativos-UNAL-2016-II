// !! //
Solución que buscaba el proyecto, fue el manejo de procesos y la sincronización de los mismos, también se manejó algo de memoria compartida 

El funcionamiento:

	Ingrece cantidad de Personas (niños y adultos) por isla, determine la isla donde parira el bote

Consideraciones:

	1. Ingrece porlomenos 2 niños.
	2. No puede dejar un Bote en una isla sin Personas.
	3. Puede modificar el Tiempo de ejecución cambiando la varible time. 

Ejecición:

	El Programa mostrara la cantidad de personas por isla y los movimientos de los mismos
