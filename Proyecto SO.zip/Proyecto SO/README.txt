Sistemas Operativos 2016
Proyecto Final.




Rodrigo Ivan Espinel Villalobos
Brayan Alexander Riascos
Johan Nicolás Torres Mendoza


El proyecto consiste en resolver el punto 6 de la primera fase de nachos, pero usando cualquier  lenguaje, se realizó en JAVA con los conceptos vistos en clase.


Fundamentación (antecedentes y justificación).


Por medio de los temas vistos a lo largo del curso, se busca resolver el problema descrito en el proyecto, este está descrito en (/http://inst.eecs.berkeley.edu/~cs162/sp13//)


Objetivos del Proyecto


1. Utilizar los conceptos vistos en clase, se buscará tener una solución del problema (pasar


todas las personas a una lista).


2. Construir un programa capaz de solucionar la problemática central del proyecto.


Descripción del Proyecto


La descripción se encuentra en (/http://inst.eecs.berkeley.edu/~cs162/sp13//).


Estrategia de Solución del Problema.


Para poder solucionar este problema, necesitaremos como mínimo 2 niños en alguna de las 2 islas, o uno en cada isla, ya que estos dos serán el punto clave para la solución.


En el problema puede haber más de dos niños, sumando el número de ellos de ambas islas, pero el algoritmo no.


El objetivo será reunir a los 2 niños en alguna isla (A) para poder comenzar con un algoritmo de traspaso de adultos de tal manera que nunca el proceso se bloquee. Luego de tener a los dos niños en la misma isla (A), el algoritmo será el siguiente:


Pasar un niño a la isla (B) y dejarlo allá, (el otro se queda en la isla (A)).


Pasar un adulto de la isla (B) a la isla (A).
Con el niño de la Isla (A), pasarlo a la isla (B) para que “recoja” al niño que habíamos llevado antes.


Pasar a ambos niños a la isla (A).


Reiniciar el algoritmo.


En caso de que, en la isla que queremos traer a todas las personas hallan tanto niños como adultos el algoritmo no variaría mucho y sería el siguiente:


Pasar un niño a la isla (B) y dejarlo allá, (el otro se queda en la isla (A)).


Pasar un adulto de la isla (B) a la isla (A).


Con el niño de la Isla (A), pasarlo a la isla (B) para que “recoja” al niño que habíamos llevado antes.


Pasar a ambos niños a la isla (A).


Repetir el algoritmo hasta que todos los adultos hallan pasado a la isla (A).


Pasar un niño a la isla (B) y recoger a un niño.


Pasar a ambos niños a la isla (A), se queda un niño en la isla (A) y repetir el proceso Anterior.


Las metodologías propuestas,  para desarrollar su implementación por medio de código, fueron 2:


 La primera intentaba dar una solución al algoritmo anteriormente explicado, esto mediante un método que realizaba operaciones entre arreglos y  constantemente llamaba a memoria para conocer su situación.


La segunda y más encaminada hacia la solución que buscaba el proyecto, fue el manejo de procesos y la sincronización de los mismos, también se manejó algo de memoria compartida 

__///Las 2 soluciones se encuent4ran adjuntas en el repositorio bajo el nombre de S


Conclusiones y Resultados.
	
Comprobamos como por medio de las metodologías (Sistemas Operativos) vistas en clase podemos enfrentar problemas comunes.
Conocimos la importancia del manejo de procesos, así como el manejo de memoria compartida y la importante razón de porque sincronizar los hilos.

