
package proyectosistemasoperativos;


import java.util.Scanner;


    
public class ProyectoSistemasOperativos {
    
    static MemoriaCompartida memoriaCompartida = new MemoriaCompartida(null,null);
    
    static Bote bote = new Bote();
    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        
        Scanner s = new Scanner(System.in);
        int id = 0, op =0;
        //----------------------------------------------------
        
        System.out.println("Isla donde se encuentra el bote:");
        System.out.println("1.Oahu");
        System.out.println("2.Molokai");
        op = s.nextInt();
        if(op == 1){
        memoriaCompartida.setIslaBote("Oahu");}
        else{memoriaCompartida.setIslaBote("Molokai");         
        }
       
        //----------------------------------------------------
       
        System.out.println("Numero de niños en Oahu");op=s.nextInt();
        for (int i = 0; i < op ;i++) {
            
            Persona persona = new Persona("Niño", "Oahu",id,bote);
           id++;
        } 
        System.out.println("Numero de adultos en Oahu");op=s.nextInt();
        for (int i = 0; i < op; i++) {
            
            Persona persona = new Persona("Adulto", "Oahu",id,bote);
           id++;
        }
        //-----------------------------------------------------
        System.out.println("Numero de niños en Molokai");op=s.nextInt();
        for (int i = 0; i < op; i++) {
            
            Persona persona = new Persona("Niño", "Molokai",id,bote);
           id++;
        }
        System.out.println("Numero de adultos en Molokai");op=s.nextInt();
        for (int i = 0; i < op; i++) {
            
            Persona persona = new Persona("Adulto", "Molokai",id,bote);
           id++;
        }
        //-----------------------------------------------------
       bote.start();
    }
    
}
