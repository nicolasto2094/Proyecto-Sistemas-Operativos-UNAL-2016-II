
package proyectosistemasoperativos;


import static java.lang.Thread.sleep;
import java.util.LinkedList;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Bote implements Runnable{
    
    int time = 2000;
    
    static LinkedList<Persona> Molokai = new LinkedList<>();
    static LinkedList<Persona> Oahu = new LinkedList<>();
    static LinkedList<Persona> bote = new LinkedList<>();
    boolean IslaObjetivo = false;
    MemoriaCompartida mc = new MemoriaCompartida();
    
    public void begin() throws InterruptedException{
        if(mc.getIslaBote().equals("Oahu")){
       subir_boteOahu();}
       else{subir_bote();}
        
    
    }
    
    
    Semaphore s = new Semaphore(1,true);
    
    public synchronized void EntrarIsla(Persona p){
        if(p.isla.equals("Oahu"))
            Oahu.addLast(p);
        else
            Molokai.addLast(p);
    }
    
    public void subir_bote() throws InterruptedException{
        sleep(1000);
        Oahu.addLast(Molokai.removeFirst());
        System.out.println(Oahu.getLast().Nombre+" Trae en bote a Ohau");
        subir_bote();
    } 

    
    public void subir_boteOahu() throws InterruptedException{
        sleep(1000);
        while(true){
            
            System.out.println("Tamaño de Molokai = "+Molokai.size()+"// Tamaño de Oahu = "+Oahu.size());
            for (int i = 0; i < 2; i++) {
                
                Molokai.addFirst(Oahu.removeFirst());
                System.out.println(Molokai.getFirst().Nombre+" sube al bote");
                sleep(time);
                if(i == 1){
                    System.out.println(Molokai.get(1).Nombre+" y "+Molokai.get(0).Nombre+" Salen de Oahu");
                    sleep(time);
                    System.out.println("Llega bote a molokai");
                }
                
            }//suben 2 niños
            
            sleep(time);System.out.println("Tamaño de Molokai = "+Molokai.size()+"// Tamaño de Oahu = "+Oahu.size());
            
            if(Oahu.size()==0){break;}// condicion de salida
            
            Oahu.addLast(Molokai.removeFirst());
            
            System.out.println(Molokai.getFirst().Nombre+" se baja en Molokai");
            sleep(time);
            System.out.println(Oahu.getLast().Nombre+" regresa a Oahu");
            sleep(time);
            System.out.println(Oahu.getLast().Nombre+" se baja en Oahu");
            //pasa uno a molokai
            
            sleep(time);System.out.println("Tamaño de Molokai = "+Molokai.size()+"// Tamaño de Oahu = "+Oahu.size());
            
            sleep(time);
            Molokai.addLast(Oahu.removeFirst());
            System.out.println(Molokai.getLast().Nombre+" parte para Molokai");
            sleep(time);
            System.out.println(Molokai.getLast().Nombre+" Llega a Molokai");

            
            sleep(time);System.out.println("Tamaño de Molokai = "+Molokai.size()+"// Tamaño de Oahu = "+Oahu.size());
            
            Oahu.addFirst(Molokai.removeFirst());
            System.out.println(Oahu.getFirst().Nombre+" sube al bote");
            sleep(time);
            System.out.println(Oahu.getFirst().Nombre+" regresa a Oahu");
            
            sleep(time);System.out.println("Tamaño de Molokai = "+Molokai.size()+"// Tamaño de Oahu = "+Oahu.size());
            
            Oahu.addFirst(Oahu.removeLast());
            
            sleep(time);
            
        }
  
    }

        
    
    @Override
    public void run() {
        try {
            begin();
        } catch (InterruptedException ex) {
            Logger.getLogger(Bote.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    Thread thread;
    public void start(){
        
        if(thread==null){
            thread=new Thread(this,"Bote");
            thread.start();}
        }

    
}
