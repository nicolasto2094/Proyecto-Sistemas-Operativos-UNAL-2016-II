
package proyectosistemasoperativos;
import static proyectosistemasoperativos.Bote.Molokai;
import static proyectosistemasoperativos.Bote.Oahu;


public class MemoriaCompartida {
    
    private static String IslaBote;
    public  static int tamOahu = Oahu.size();
    public  static int tamMolokai = Molokai.size();

    public void Actualizar(){
            tamMolokai = Molokai.size();
            tamOahu = Molokai.size();
    }
    
    
    
    public MemoriaCompartida() {
    }

    public MemoriaCompartida(String IslaObjetivo, String IslaBote) {
        MemoriaCompartida.IslaBote = IslaBote;
    }

    public String getIslaBote() {
        return IslaBote;
    }

    public void setIslaBote(String IslaBote) {
        this.IslaBote = IslaBote;
    }
    
    
}
