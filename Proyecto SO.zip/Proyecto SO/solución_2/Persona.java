
package proyectosistemasoperativos;

import java.util.logging.Level;
import java.util.logging.Logger;


public class Persona implements Runnable{
    
    String tipo;
    String isla;
    
    int id;
    int personas_en_la_isla;
    Bote bote;
    MemoriaCompartida mc = new MemoriaCompartida();
    
    Thread thread = new Thread();
    public String Nombre;
    
    public Persona(String tipo, String isla, int id, Bote bote) {
        
        this.bote = bote;
        this.tipo = tipo;
        this.isla = isla;
        this.id = id;
     
                
        this.Nombre = tipo + String.valueOf(id);
        thread=null;
        start();
   }
    
    public void Subir_Bote(Persona persona) throws InterruptedException{
          // 
          bote.EntrarIsla(this);
          
           
    }

    @Override
    public void run() {
        try {
            Subir_Bote(this);
        } catch (InterruptedException ex) {
            Logger.getLogger(Persona.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void stop(){
        thread.stop();
    }
    public void start(){
        
    if(thread==null){
        
        thread=new Thread(this,Nombre);
        thread.start();}
    }
    
    
}
